import tkinter
import tkinter.messagebox
import customtkinter
import glob
import threading
import time
import read
import queue
from serial_instance import get_serial, open_serial, close_serial

customtkinter.set_appearance_mode("Dark")  # Modes: "System" (standard), "Dark", "Light"
customtkinter.set_default_color_theme(
    "blue"
)  # Themes: "blue" (standard), "green", "dark-blue"


class DataReader(threading.Thread):
    def __init__(self, app):
        threading.Thread.__init__(self)
        self.app = app
        self.running = True
        self.queue = queue.Queue()
        self.com_port = None

    def run(self):
        while self.running:
            if self.com_port:
                try:
                    values = read.get_realtime(str(self.com_port))
                    self.queue.put(values)
                    self.app.after(0, self.app.process_queue)
                except Exception as e:
                    print(f"Error reading values: {e}")
            time.sleep(0.1)

    def stop(self):
        self.running = False

    def set_com_port(self, com_port):
        self.com_port = com_port


class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        # configure window
        self.title("ROTOM CONTROL")
        self.geometry(f"{1100}x{650}")
        self.state("zoomed")
        # configure grid layout (4x4)
        self.grid_columnconfigure((1, 2, 3, 4), weight=1)

        # self.grid_columnconfigure((1, 2), weight=0)
        self.grid_rowconfigure((0, 1, 2), weight=1)

        # create sidebar frame with widgets
        self.sidebar_frame = customtkinter.CTkFrame(self, width=140, corner_radius=0)
        self.sidebar_frame.grid(row=0, column=0, rowspan=4, sticky="nsew")
        # self.sidebar_frame.grid_rowconfigure((0, 1), weight=1)
        self.logo_label = customtkinter.CTkLabel(
            self.sidebar_frame,
            text="ROTOM\nCONTROL",
            font=customtkinter.CTkFont(size=20, weight="bold"),
        )
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))

        self.data_reader = DataReader(self)
        self.data_reader.start()
        self.connected_com_port = None

        self.selected_com_port = customtkinter.StringVar(value="")
        self.com_port_optionmenu = customtkinter.CTkOptionMenu(
            self.sidebar_frame,
            # values="",
            values=self.get_COM_port(),
            variable=self.selected_com_port,
            # command=self.com_port_select_event,
        )
        self.com_port_optionmenu.grid(row=1, column=0, padx=20, pady=(10, 10))

        self.sidebar_button_refresh = customtkinter.CTkButton(
            self.sidebar_frame,
            command=self.sidebar_button_refresh,
            text="Refresh",
        )
        self.sidebar_button_refresh.grid(row=2, column=0, padx=20, pady=10)

        self.sidebar_button_connect = customtkinter.CTkButton(
            self.sidebar_frame,
            command=self.sidebar_button_connect,
            text="Connect",
        )
        self.sidebar_button_connect.grid(row=3, column=0, padx=20, pady=10)

        self.sidebar_button_3 = customtkinter.CTkButton(
            self.sidebar_frame,
            command=self.sidebar_button_disconnect,
            text="Disconnect",
        )
        self.sidebar_button_3.grid(row=4, column=0, padx=20, pady=10)

        self.sidebar_is_connected = customtkinter.CTkLabel(
            self.sidebar_frame,
            # fg_color="grey17",
            text="Disconnected",
        )
        self.sidebar_is_connected.grid(row=5, column=0, padx=20, pady=10)

        self.sidebar_button_4 = customtkinter.CTkButton(
            self.sidebar_frame,
            command=self.sidebar_button_read,
            text="Read",
        )
        self.sidebar_button_4.grid(row=6, column=0, padx=20, pady=10)

        self.sidebar_button_5 = customtkinter.CTkButton(
            self.sidebar_frame,
            command=self.sidebar_button_write,
            text="Write",
        )
        self.sidebar_button_5.grid(row=7, column=0, padx=20, pady=10)
        # self.appearance_mode_label = customtkinter.CTkLabel(
        #     self.sidebar_frame, text="Appearance Mode:", anchor="w"
        # )
        # self.appearance_mode_label.grid(row=6, column=0, padx=20, pady=(10, 0))

        self.appearance_mode_optionemenu = customtkinter.CTkOptionMenu(
            self.sidebar_frame,
            values=["Light", "Dark", "System"],
            command=self.change_appearance_mode_event,
        )
        self.appearance_mode_optionemenu.grid(row=8, column=0, padx=20, pady=(10, 10))

        # self.scaling_label = customtkinter.CTkLabel(
        #     self.sidebar_frame, text="UI Scaling:", anchor="w"
        # )
        # self.scaling_label.grid(row=8, column=0, padx=20, pady=(10, 0))
        self.scaling_optionemenu = customtkinter.CTkOptionMenu(
            self.sidebar_frame,
            values=["80%", "90%", "100%", "110%", "120%"],
            command=self.change_scaling_event,
        )
        self.scaling_optionemenu.grid(row=9, column=0, padx=20, pady=(10, 20))

        # create main entry and button
        # self.entry = customtkinter.CTkEntry(self, placeholder_text="type")
        # self.entry.grid(
        #     row=3, column=1, columnspan=3, padx=(20, 0), pady=(20, 20), sticky="nsew"
        # )

        # self.main_button_1 = customtkinter.CTkButton(
        #     master=self,
        #     fg_color="transparent",
        #     border_width=2,
        #     text_color=("gray10", "#DCE4EE"),
        #     text="send",
        # )
        # self.main_button_1.grid(
        #     row=3, column=4, padx=(20, 20), pady=(20, 20), sticky="nsew"
        # )

        # create textbox
        # self.textbox = customtkinter.CTkTextbox(self, width=250)
        # self.textbox.grid(row=0, column=1, padx=(20, 0), pady=(20, 0), sticky="nsew")

        # create tabview
        self.tabview = customtkinter.CTkTabview(self)
        self.tabview.grid(
            row=0,
            rowspan=2,
            column=1,
            columnspan=3,
            padx=(20, 0),
            pady=(20, 20),
            sticky="nsew",
        )
        self.tabview.add("Setting")
        self.tabview.add("Detection")
        self.tabview.add("Sensor")
        self.tabview.add("Communication")
        self.tabview.add("Console")
        self.tabview.add("Plot")

        self.tabview.tab("Setting").grid_columnconfigure(0, weight=1)
        self.tabview.tab("Setting").grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        self.tabview.tab("Sensor").grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        self.tabview.tab("Communication").grid_columnconfigure(0, weight=1)
        self.tabview.tab("Console").grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        self.tabview.tab("Console").grid_rowconfigure(
            (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10), weight=1
        )

        self.optionmenu_1 = customtkinter.CTkOptionMenu(
            self.tabview.tab("Setting"),
            dynamic_resizing=True,
            values=["BLDC", "FOC"],
        )
        self.optionmenu_1.grid(row=0, column=0, padx=20, pady=(20, 10))

        self.optionmenu_2 = customtkinter.CTkOptionMenu(
            self.tabview.tab("Setting"),
            dynamic_resizing=True,
            values=["True", "False"],
        )
        self.optionmenu_2.grid(row=1, column=0, padx=20, pady=(10, 10))

        self.string_input_button = customtkinter.CTkButton(
            self.tabview.tab("Setting"),
            text="Open CTkInputDialog",
            command=self.open_input_dialog_event,
        )
        self.string_input_button.grid(row=2, column=0, padx=20, pady=(10, 10))

        self.sensor_option = customtkinter.CTkOptionMenu(
            self.tabview.tab("Sensor"),
            dynamic_resizing=True,
            values=["None", "AS5047", "ABI", "Halll"],
        )
        self.sensor_option.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="")

        self.sensor_ABI_option = customtkinter.CTkOptionMenu(
            self.tabview.tab("Sensor"),
            dynamic_resizing=True,
            values=["None", "AS5047", "ABI", "Halll"],
        )
        self.sensor_ABI_option.grid(row=1, column=0, padx=20, pady=(20, 10), sticky="")

        self.textbox = customtkinter.CTkTextbox(
            self.tabview.tab("Console"),
            corner_radius=10,
        )
        self.textbox.grid(
            row=0,
            rowspan=11,
            column=0,
            columnspan=6,
            padx=(20, 20),
            pady=(20, 20),
            sticky="nsew",
        )
        self.entry = customtkinter.CTkEntry(
            self.tabview.tab("Console"),
            placeholder_text="type",
        )
        self.entry.grid(
            row=11, column=0, columnspan=5, padx=(20, 0), pady=(20, 20), sticky="nsew"
        )

        self.main_button_1 = customtkinter.CTkButton(
            self.tabview.tab("Console"),
            fg_color="transparent",
            border_width=2,
            text_color=("gray10", "#DCE4EE"),
            text="send",
        )
        self.main_button_1.grid(
            row=11, column=5, padx=(20, 20), pady=(20, 20), sticky="nsew"
        )

        self.tabview2 = customtkinter.CTkTabview(self)
        self.tabview2.grid(
            row=0,
            rowspan=3,
            column=4,
            padx=(20, 20),
            pady=(20, 20),
            sticky="nsew",
        )
        self.tabview2.add("Realtime Data")
        self.tabview2.tab("Realtime Data").grid_columnconfigure((0, 1), weight=1)
        self.tabview2.tab("Realtime Data").grid_rowconfigure(
            (0, 1, 2, 3, 4, 5, 6, 7),
            weight=1,
        )
        self.real_voltage_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Voltage", font=("", 20)
        )

        self.real_voltage_text.grid(row=0, column=0, padx=0, pady=0, sticky="nsew")

        self.real_voltage_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime().v_in) + " V",
            font=("", 30),
        )

        self.real_voltage_read.grid(row=1, column=0, padx=0, pady=0, sticky="n")

        self.real_duty_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Duty Cycle", font=("", 20)
        )

        self.real_duty_text.grid(row=0, column=1, padx=0, pady=0, sticky="nsew")

        self.real_duty_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime().duty_cycle_now * 100) + " %",
            font=("", 30),
        )

        self.real_duty_read.grid(row=1, column=1, padx=0, pady=0, sticky="n")

        self.real_mot_curr_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Motor Current", font=("", 20)
        )

        self.real_mot_curr_text.grid(row=2, column=0, padx=0, pady=0, sticky="nsew")

        self.real_mot_curr_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime().duty_cycle_now * 100) + " %",
            font=("", 30),
        )

        self.real_mot_curr_read.grid(row=3, column=0, padx=0, pady=0, sticky="n")

        self.real_batt_curr_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Battery Current", font=("", 20)
        )

        self.real_batt_curr_text.grid(row=2, column=1, padx=0, pady=0, sticky="nsew")

        self.real_batt_curr_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime().duty_cycle_now * 100) + " %",
            font=("", 30),
        )

        self.real_batt_curr_read.grid(row=3, column=1, padx=0, pady=0, sticky="n")

        self.real_erpm_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="ERPM", font=("", 20)
        )

        self.real_erpm_text.grid(row=4, column=0, padx=0, pady=0, sticky="nsew")

        self.real_erpm_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime().duty_cycle_now * 100) + " %",
            font=("", 30),
        )

        self.real_erpm_read.grid(row=5, column=0, padx=0, pady=0, sticky="n")

        self.real_temp_mos_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="MOSFET TEMP", font=("", 20)
        )

        self.real_temp_mos_text.grid(row=4, column=1, padx=0, pady=0, sticky="nsew")

        self.real_temp_mos_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime(self.connected_com_port).temp_fet) + " ℃",
            font=("", 30),
        )

        self.real_temp_mos_read.grid(row=5, column=1, padx=0, pady=0, sticky="n")

        self.real_power_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Power", font=("", 20)
        )

        self.real_power_text.grid(row=6, column=0, padx=0, pady=0, sticky="nsew")

        self.real_power_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime(self.connected_com_port).temp_fet) + " ℃",
            font=("", 30),
        )

        self.real_power_read.grid(row=7, column=0, padx=0, pady=0, sticky="n")

        self.real_falut_code_text = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"), text="Fault Code", font=("", 20)
        )

        self.real_falut_code_text.grid(row=6, column=1, padx=0, pady=0, sticky="nsew")

        self.real_falut_read = customtkinter.CTkLabel(
            self.tabview2.tab("Realtime Data"),
            text="",
            # text=str(read.get_realtime(self.connected_com_port).temp_fet) + " ℃",
            font=("", 30),
        )

        self.real_falut_read.grid(row=7, column=1, padx=0, pady=0, sticky="n")

        self.tabview3 = customtkinter.CTkTabview(self)
        self.tabview3.grid(
            row=2,
            column=1,
            columnspan=3,
            padx=(20, 0),
            pady=(0, 20),
            sticky="nsew",
        )
        self.tabview3.add("Control Panel")
        self.tabview3.tab("Control Panel").grid_columnconfigure((0, 1, 2, 3), weight=1)
        self.tabview3.tab("Control Panel").grid_rowconfigure((0, 1, 2), weight=1)

        self.radio_button_1 = customtkinter.CTkCheckBox(
            self.tabview3.tab("Control Panel"),
            text="Duty",
            onvalue="on",
            offvalue="off",
        )
        self.radio_button_1.grid(row=0, column=0, pady=10, padx=20, sticky="n")

        self.radio_button_2 = customtkinter.CTkCheckBox(
            self.tabview3.tab("Control Panel"),
            text="Current",
            onvalue="on",
            offvalue="off",
        )
        self.radio_button_2.grid(row=0, column=1, pady=10, padx=20, sticky="n")

        self.radio_button_3 = customtkinter.CTkCheckBox(
            self.tabview3.tab("Control Panel"),
            text="Position",
            onvalue="on",
            offvalue="off",
        )
        self.radio_button_3.grid(row=0, column=2, pady=10, padx=20, sticky="n")

        duty = tkinter.IntVar()
        self.slider_duty = customtkinter.CTkSlider(
            self.tabview3.tab("Control Panel"),
            orientation="vertical",
            from_=0,
            to=100,
            # number_of_steps=10,
            width=20,
            variable=duty,
            # height=100,
        )

        self.slider_duty.grid(row=1, column=0, padx=(10, 10), pady=(10, 10), sticky="")
        self.slider_duty.set(0)
        self.text_duty = customtkinter.CTkLabel(
            self.tabview3.tab("Control Panel"), textvariable=duty, font=("", 20)
        )

        self.text_duty.grid(row=2, column=0, padx=0, pady=0, sticky="n")

        current = tkinter.IntVar()
        self.slider_current = customtkinter.CTkSlider(
            self.tabview3.tab("Control Panel"),
            orientation="vertical",
            from_=0,
            to=100,
            # number_of_steps=10,
            width=20,
            variable=current,
            # height=100,
        )

        self.slider_current.grid(
            row=1, column=1, padx=(10, 10), pady=(10, 10), sticky=""
        )
        self.slider_current.set(0)
        self.text_current = customtkinter.CTkLabel(
            self.tabview3.tab("Control Panel"), textvariable=current, font=("", 20)
        )

        self.text_current.grid(row=2, column=1, padx=0, pady=0, sticky="n")

        self.start_button = customtkinter.CTkButton(
            self.tabview3.tab("Control Panel"),
            command=self.start_button_event,
            text="Start",
            fg_color="#00D664",
            hover_color="#00AB53",
        )
        self.start_button.grid(row=0, column=3, padx=0, pady=20, sticky="s")

        self.stop_button = customtkinter.CTkButton(
            self.tabview3.tab("Control Panel"),
            command=self.stop_button_event,
            text="STOP",
            fg_color="red",
            hover_color="#B7181E",
        )
        self.stop_button.grid(row=1, column=3, padx=0, pady=0, sticky="n")

        # self.sidebar_button_blank.configure(state="disabled", text=" ")
        self.com_port_optionmenu.set("Ports")
        self.appearance_mode_optionemenu.set("Theme")
        self.scaling_optionemenu.set("Scale")

        self.optionmenu_1.set("ESC Mode")
        self.optionmenu_2.set("Motor Direction")
        self.sensor_option.set("Sensor Type")
        self.sensor_ABI_option.set("ABI Counts")

        # self.slider_1.configure(command=self.progressbar_2.set)
        # self.slider_2.configure(command=self.progressbar_3.set)
        # self.progressbar_1.configure(mode="indeterminnate")
        # self.progressbar_1.start()
        self.textbox.insert(
            "0.0",
            "CTkTextbox\n\n"
            + "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\n\n"
            * 20,
        )
        # self.seg_button_1.configure(values=["CTkSegmentedButton", "Value 2", "Value 3"])
        # self.seg_button_1.set("Value 2")

        # if self.is_connected == True:
        #     self.update_labels()

    def open_input_dialog_event(self):
        dialog = customtkinter.CTkInputDialog(
            text="Type in a number:", title="Safety Warning"
        )
        print("CTkInputDialog:", dialog.get_input())

    def change_appearance_mode_event(self, new_appearance_mode: str):
        customtkinter.set_appearance_mode(new_appearance_mode)

    def change_scaling_event(self, new_scaling: str):
        new_scaling_float = int(new_scaling.replace("%", "")) / 100
        customtkinter.set_widget_scaling(new_scaling_float)

    def com_port_select_event(self):
        # customtkinter.set_appearance_mode(new_appearance_mode)
        print(self.values)

    def get_COM_port(self):
        COM = glob.glob("/dev/cu.*")
        # COM = COM[2:]
        # cleaned_ports = [port.replace("/dev/cu.", "") for port in COM]
        return COM
        # return cleaned_ports

    def sidebar_button_refresh(self):
        # self.get_COM_port()
        self.com_port_optionmenu.configure(values=self.get_COM_port())

        print("Refresh")

    def sidebar_button_connect(self):
        self.connected_com_port = self.selected_com_port.get()
        self.data_reader.set_com_port(self.connected_com_port)
        # print(f"Connected to {self.connected_com_port}")
        # self.sidebar_button_connect.configure(state="disabled")
        # self.sidebar_button_connect.configure(state="normal")

    def sidebar_button_disconnect(self):
        self.connected_com_port = None
        self.data_reader.set_com_port(None)
        read.get_finish()
        read.serial_status = False
        self.is_connected()
        # self.is_connected()
        # print("Disconnected")

    def sidebar_button_read(self):
        read.get_realtime(self.connected_com_port)
        print("Read")

    def sidebar_button_write(self):
        print("Write")

    def start_button_event(self):
        print("Start Motor")

    def stop_button_event(self):
        print("Stop Motor")

    def is_connected(self):
        # print(read.serial_status)
        return read.serial_status

    def print_fault_code(self, number):
        fault_codes = {
            0: "NONE",
            1: "OVER\nVOLTAGE",
            2: "UNDER\nVOLTAGE",
            3: "DRV\nERROR",
            4: "ABS\nOVER CURRENT",
            5: "OVER\nFET TEMP",
        }
        if number in fault_codes:
            return fault_codes[number]
        else:
            print(number)

    def update_labels(self, values):
        if values:
            self.real_voltage_read.configure(
                text=f"{values.v_in}v"
                # text=str(read.get_realtime(str(self.connected_com_port)).v_in) + "v"
            )
            self.real_duty_read.configure(
                text=f"{values.duty_cycle_now * 100:.2f}%"
                # text=str(read.get_realtime(str(self.connected_com_port)).duty_cycle_now * 100)
                # + "%"
            )
            self.real_mot_curr_read.configure(text=f"{values.avg_motor_current} A")

            self.real_batt_curr_read.configure(text=f"{values.avg_input_current} A")
            self.real_erpm_read.configure(text=f"{values.rpm:.0f} rpm")
            self.real_temp_mos_read.configure(text=f"{values.temp_fet} ℃")
            self.real_power_read.configure(
                text=f"{values.v_in * values.avg_input_current} W"
            )
            self.real_falut_read.configure(
                text=f"{self.print_fault_code(ord(values.mc_fault_code))}"
            )

        else:
            # 값이 없는 경우 모든 라벨을 초기화합니다.
            for label in [
                self.real_voltage_read,
                self.real_duty_read,
                self.real_mot_curr_read,
                self.real_batt_curr_read,
                self.real_erpm_read,
                self.real_temp_mos_read,
                self.real_power_read,
                self.real_falut_read,
            ]:
                label.configure(text="N/A")

        if read.serial_status:
            self.sidebar_is_connected.configure(text="Connected")
        elif read.serial_status == False:
            self.sidebar_is_connected.configure(text="Disconnected")

    def on_closing(self):
        self.data_reader.stop()
        # self.data_reader.join()
        self.destroy()
        self.sidebar_button_disconnect()

    def process_queue(self):
        try:
            values = self.data_reader.queue.get_nowait()
            self.update_labels(values)
        except queue.Empty:
            pass
        finally:
            self.after(100, self.process_queue)  # 다음 큐 처리 예약


if __name__ == "__main__":
    app = App()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()
