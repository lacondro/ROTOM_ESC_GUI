import pyvesc
from serial_instance import open_serial, get_serial, close_serial

from pyvesc import VESC
from pyvesc.VESC.messages import (
    GetVersion,
    GetValues,
    SetRPM,
    SetCurrent,
    SetRotorPositionMode,
    GetRotorPosition,
)

# import serial
# import time
serial_status = False
# serialport = "/dev/cu.usbmodem3041"


def get_realtime(serialport):
    # with serial.Serial(serialport, baudrate=115200, timeout=0.05) as ser:
    global serial_status
    with open_serial(serialport) as ser:
        try:

            ser.write(pyvesc.encode_request(GetValues))
            # print(ser.in_waiting)
            # if ser.in_waiting > 128:
            (response, consumed) = pyvesc.decode(ser.read(128))
            serial_status = True

            # Print out the values
            # try:
            #     print("MOSFET TEMP: ", response.temp_fet)
            #     print("Motor Current: ", response.avg_motor_current)
            #     print("Batt Current: ", response.avg_input_current)
            #     print("Duty Cycle: ", response.duty_cycle_now)
            #     print("rpm: ", response.rpm)
            #     print("Voltage: ", response.v_in)
            #     print("Fault Code: ", ord(response.mc_fault_code))
            #     print("Angle: ", response.pid_pos_now)
            #     print("ID: ", ord(response.app_controller_id))
            #     print("")

        # else:
        #     serial_status = False

        #     # ToDo: Figure out how to isolate rotor position and other sensor data
        #     #       in the incoming datastream
        #     # try:
        #     #    print(response.rotor_pos)
        #     # except:
        #     #    pass
        # pass

        # time.sleep(0.1)

        except KeyboardInterrupt:
            # Turn Off the VESC
            ser.write(pyvesc.encode(SetCurrent(0)))

            # serial_status = False

    return response


def get_finish():
    global serial_status
    close_serial()
    # print("serial closed")
    serial_status = False


if __name__ == "__main__":
    get_realtime("/dev/cu.usbmodem3041")
